import React, { useState } from "react";
import styled from "styled-components";

import Button from "./components/button";
import Stack from "./components/stack";

const Root = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
`;

const Title = styled.label`
  margin-bottom: 16px;
  font-family: "Josefin Sans", sans-serif;
  font-size: 18px;
  font-weight: 400;
`;

const Input = styled.input`
  border: 2px solid black;
  outline-color: #2b60de;
  font-family: "Josefin Sans", sans-serif;
  font-size: 16px;
  font-weight: 400;
  line-height: 18px;
  padding: 8px;
  width: 100%;
`;

const Controls = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 20px 0;
  width: 100%;
`;

const Buttons = styled.div`
  display: flex;
  justify-content: space-around;
  margin: 20px 0;
  width: 100%;
`;

function CallStack() {
  const [commands, setCommands] = useState([]);
  const [value, setValue] = useState("");

  const handleCommandChange = (event) => {
    setValue(event.target.value);
  };

  const handleCommandKeyDown = (event) => {
    if (event.key === "Enter") {
      handlePush();
    }
  };

  const handlePush = () => {
    if (!value) {
      return;
    }

    const nextCommand = {
      label: value,
      done: false
    };

    setCommands([...commands, nextCommand]);
    setValue("");
  };

  const handlePop = () => {
    if (!commands.length) {
      return;
    }

    const lastCommand = commands[commands.length - 1];
    lastCommand.done = true;

    setCommands([...commands.slice(0, commands.length - 1), lastCommand]);

    setTimeout(() => {
      // remove done command
      setCommands([...commands.slice(0, commands.length - 1)]);
    }, 250);
  };

  const handleRestart = () => {
    setCommands([]);
  };

  return (
    <Root>
      <Controls>
        <Title>Enter any number :</Title>
        <Input
          onChange={handleCommandChange}
          onKeyDown={handleCommandKeyDown}
          value={value}
        />
        <Buttons>
          <Button onClick={handlePush}>Push</Button>
          <Button onClick={handlePop}>Pop</Button>
          <Button onClick={handleRestart}>Restart</Button>
        </Buttons>
      </Controls>
      <Stack commands={commands} />
    </Root>
  );
}

export default CallStack;
