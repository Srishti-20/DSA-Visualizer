import React from "react";
import styled from "styled-components";

const Root = styled.button`
  background-color: ${(props) => props.backgroundColor || "#3BB9FF"};
  color: ${(props) => props.color || "black"};
  margin-right: 8px;
  border: 2px solid black;
  border-radius: 4px;
  box-shadow: 0 2px #333;
  font-family: "Josefin Sans", sans-serif;
  font-size: 16px;
  padding: 8px 16px;
  cursor: pointer;
  outline: none;
  opacity: 1;

  &:hover,
  &:focus {
    opacity: 0.8;
  }

  &:active {
    opacity: 0.9;
    box-shadow: 0 1px #333;
    transform: translateY(1px);
  }
`;

const Button = ({ children, onClick }) => {
  return <Root onClick={onClick}>{children}</Root>;
};

export default Button;
