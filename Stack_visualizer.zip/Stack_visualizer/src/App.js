import React from "react";
import styled from "styled-components";

import CallStack from "./call-stack";

const Root = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin: 0 auto 40px auto;
  width: 400px;
  @media (max-width: 480px) {
    width: 300px;
  }
`;

const Title = styled.h1`
  font-family: "Josefin Sans", sans-serif;
  font-size: 32px;
  text-transform: uppercase;
  text-align: center;
  @media (max-width: 480px) {
    font-size: 24px;
  }
`;

function App() {
  return (
    <Root>
      <Title>Stack Visualizer</Title>
      <CallStack />
    </Root>
  );
}

export default App;
