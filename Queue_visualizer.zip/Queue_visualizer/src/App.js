import React from 'react';
import './App.css';

import Queues from './components/Queues';

function App() {

  return (
    <div className="App">
      <h1>QUEUES VISUALZER</h1>
      <Queues />
    </div>
  );
}

export default App;
