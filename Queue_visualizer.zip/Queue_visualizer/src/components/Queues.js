// Queue.js
import React, { useState } from 'react';
import './Queues.css';

const Queues = () => {
  const [queue, setQueue] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [frontElement, setFrontElement] = useState(null);

  const enqueue = () => {
    if (inputValue !== '') {
      setQueue([...queue, inputValue]);
      setInputValue('');
      if (queue.length === 0) {
        setFrontElement(inputValue);
      }
    }
  };

  const dequeue = () => {
    if (queue.length > 0) {
      const newQueue = [...queue];
      newQueue.shift();
      setQueue(newQueue);
      if (newQueue.length === 0) {
        setFrontElement(null);
      } else {
        setFrontElement(newQueue[0]);
      }
    }
  };

  return (
    <div className="queue-container">
      <div className="queue-input">
        <p><b>Enter any number:</b></p>
        <input
          type="Number"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="input-box"
        />
      </div>
      <div className="queue-controls">
        <button className="btn btn-primary mx-2 my-2" onClick={() => enqueue(Math.floor(Math.random() * 100))}>Enqueue</button>
        <button className="btn btn-primary mx-2 my-2" onClick={dequeue}>Dequeue</button>
      </div>
      <div className='queue-analysis'>
      <p>Queue Length: {queue.length}</p>
      <p>Front Element: {frontElement !== null ? frontElement : '-'}</p>
      </div>
      <div className="queue-result">
        <p><b>Resultant Queue:</b></p>
        <div className="small-queue">
          {queue.map((item, index) => (
            <div key={index} className={`queue-item ${index === queue.length - 1 ? 'enqueued' : ''}`}>
              {item}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Queues;
